import sys

# Fungsi pembantu: Cetak header tabel
def print_headers():
    # Fungsi ini mencetak header dari tabel.
    print("| {: <2} | {: <25} | {: <8} | {: <10} | {: <3} |".format("No", "Smartphone", "Price", "Screensize", "RAM"))
    print("="*64)

# Fungsi untuk mencetak seluruh konten tabel
def print_table(filename):
    # Fungsi ini membaca file dan mencetak kontennya dalam format tabel
    try:
        with open(filename, "r") as f:
            print_headers()
            for i, line in enumerate(f.readlines()):
                name, price, screensize, ram = line.strip().split("\t")
                print("| {: <2} | {: <25} | {: <8} | {: <10} | {: <3} |".format(i, name, price, screensize, ram))
    # Menangani error ketika file tidak ada
    except FileNotFoundError:
        print("Maaf, file input tidak ada")
        exit()

# Fungsi untuk mencari substring tertentu
def search_phone(filename, keyword):
    # Fungsi ini mencari kata kunci tertentu dalam file dan mencetak baris yang cocok
    try:
        with open(filename, "r") as f:
            print_headers()
            data = [line.strip().split("\t") for line in f.readlines()]
            results = [row for row in data if keyword.lower() in row[0].lower()]
            for i, result in enumerate(results, start=1):
                name, price, screensize, ram = result
                print("| {: <2} | {: <25} | {: <8} | {: <10} | {: <3} |".format(i, name, price, screensize, ram))
            print("Jumlah data hasil pencarian: ", len(results))
    # Menangani error ketika file tidak ada
    except FileNotFoundError:
        print("Maaf, file input tidak ada")
        exit()

# Fungsi untuk mendapatkan statistik deskriptif untuk kolom tertentu
def desc_stat(filename, column):
    # Fungsi ini menghitung dan mencetak minimum, maksimum dan rata-rata dari kolom tertentu dalam file
    try:
        with open(filename, "r") as f:
            data = [line.strip().split("\t") for line in f.read().splitlines()]
            if column not in range(4) or column == 0:
                print("Kolom tidak valid")
                return
            values = [float(row[column]) for row in data]
            min_val = min(values)
            max_val = max(values)
            avg_val = sum(values) / len(values)
            print("Minimum: {:.2f}".format(min_val))
            print("Maksimum: {:.2f}".format(max_val))
            print("Rata-rata: {:.2f}".format(avg_val))
    # Menangani error ketika file tidak ada
    except FileNotFoundError:
        print("Maaf, file input tidak ada")
        exit()

if __name__ == '__main__':
    # Fungsi utama: Memeriksa argumen baris perintah dan memanggil fungsi yang diperlukan
    if len(sys.argv) != 4:
        print("Usage: python script_name.py <file_path> <search_keyword> <column_num>")
        sys.exit(1)

    file_path = sys.argv[1]
    key = sys.argv[2]
    column_num = int(sys.argv[3])

    # Panggil fungsi yang diperlukan di sini
    print_table(file_path)
    print() #Tambah baris baru
    search_phone(file_path, key)
    desc_stat(file_path, column_num)

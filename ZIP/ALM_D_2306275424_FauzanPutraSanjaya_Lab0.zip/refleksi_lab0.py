#Mencetak Judul Program
print("Biodata Anak Pacil")

#Garis pembatas agar lebih enak dibaca
print("===================================")

#Melakukan input biodata
print("Halo!, Silakan isi data berikut")
nama_lengkap = input("Nama Lengkap: ")
nama_panggilan = input("Nama Panggilan: ")
tempat_lahir = input("Tempat Lahir: ")
tanggal_lahir = input ("Tanggal Lahir (DD): ")
bulan_lahir = input("Bulan Lahir: ")
tahun_lahir = int(input("Tahun Lahir(YYYY): "))
hobi = input("Hobi: ")

#Menghitung umur pengguna tahun ini
umur = 2023 - tahun_lahir

#Garis pembatas agar lebih enak dibaca
print("===================================")

#Mencetak perkenalan diri
print("Halo, perkenalkan namaku " + nama_lengkap + ". Aku biasa dipanggil " + nama_panggilan + ".")
print("Aku lahir di " + tempat_lahir + " pada tanggal " + tanggal_lahir + " " + bulan_lahir + " " + str(tahun_lahir) + " .")
print("Tahun ini aku berumur " + str(umur) + " tahun.")
print("Aku juga punya hobi lho, hobiku yaitu " + hobi + ".")
print("Salam kenal!!")
